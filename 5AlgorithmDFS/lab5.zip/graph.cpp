#include "graph.h"

string Graph::toString(){
	string output;
	for(std::map<int,Node>::iterator it = allNodes.begin(); it != allNodes.end(); ++it)
	{
		output += it->second.toString() + "\n";
	}

	return output;
};

string Graph::convertToString(int myInt){
	string out = to_string(myInt);
	return out;
};

vector<Node> Graph::getPostOrder(){

	vector<Node> newNodes;

	for(map<int,Node>::iterator it = allNodes.begin(); it != allNodes.end(); ++it){
		if(!it->second.isVisited){
			vector<Node> temp = dfs(it->second);
			newNodes.insert(newNodes.end(), temp.begin(), temp.end());
		}
	}
	return newNodes;
};

vector<Node> Graph::dfs(Node& currentNode){

	vector<Node> newNodes;

	currentNode.isVisited = true;
	for(unsigned int i = 0; i < currentNode.adjacentNodes.size(); i++){

		if(allNodes[currentNode.adjacentNodes[i]].isVisited != true){
			vector<Node> temp = dfs(allNodes[i]);
			newNodes.insert(newNodes.end(), temp.begin(), temp.end());
		}

	}
	newNodes.push_back(currentNode);

	return newNodes;
};