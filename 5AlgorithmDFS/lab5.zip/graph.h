#pragma once

#include <map>
#include <iostream>
#include <sstream>
#include <vector>
#include <map>
#include "node.h"

using namespace std;

class Graph{
public:
	Graph(){}
	~Graph(){}

	map<int, Node> allNodes;

	string toString();
	string convertToString(int myInt);
	vector<Node> getPostOrder();
	vector<Node> dfs(Node& currentNode);
};