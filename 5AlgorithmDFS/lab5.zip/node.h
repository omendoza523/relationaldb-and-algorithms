#pragma once

#include <vector>
#include <string>
#include <set>

using namespace std;

class Node{
public:
	Node(){}
	~Node(){}

	int nodeName;
	vector<int> adjacentNodes;
	bool isVisited = false;
	int postOrderNumber = -1;

	string toString(){
		string output;
		output += "R" + convertToString(nodeName) + ":";
		for(unsigned int i = 0; i < adjacentNodes.size(); i++)
		{
			if(i > 0){
                output += ",";
            }
            output += "R" + convertToString(adjacentNodes[i]);
		}
		return output;
	};

	string convertToString(int n){
		string out = to_string(n);
		return out;
	};

	bool isCyclic(){
        for(unsigned int i = 0; i < adjacentNodes.size(); i++)
		{
			int signedInt = (int) i;
			if(signedInt == nodeName){
				return true;
			}
		}
		return false;
	};

	bool operator<(const Node& currentNode) const{
        
		if(nodeName < currentNode.nodeName){
            return true;
        }
		else{
            return false;
        }
	};

	bool operator==(const Node& currentNode){

		if(nodeName == currentNode.nodeName){
            return true;
        }
		else{
            return false;
        }
	};
};